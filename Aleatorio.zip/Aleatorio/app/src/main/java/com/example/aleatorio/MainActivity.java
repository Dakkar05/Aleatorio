package com.example.aleatorio;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private TextInputEditText ingresar;
    private TextView resultado;
    private Button lanzar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ingresar = (TextInputEditText) findViewById(R.id.ingresar);
        resultado=(TextView) findViewById(R.id.result);
        lanzar= (Button) findViewById(R.id.buttonlanzar);
        lanzar.setOnClickListener(this);
        


    }
    private void Lanzar(){
        int num = Integer.valueOf(ingresar.getText().toString());
        for (int i=0;i<=num;i++){
            int random = (int)(Math.random()*num);
            String mos = String.valueOf(random);
            resultado.setText(mos);
        }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        

    }

    @Override
    public void onClick(View view) {
        if (lanzar==view){
            Lanzar();
        }
    }
}